from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
import os


def generate_launch_description():
    tc_wam_launch = os.path.join(
        get_package_share_directory("openflex_tc_wam"),
        "launch",
        "offline_tc_wam.launch.py",
    )
    return LaunchDescription(
        [IncludeLaunchDescription(PythonLaunchDescriptionSource(tc_wam_launch))]
    )
