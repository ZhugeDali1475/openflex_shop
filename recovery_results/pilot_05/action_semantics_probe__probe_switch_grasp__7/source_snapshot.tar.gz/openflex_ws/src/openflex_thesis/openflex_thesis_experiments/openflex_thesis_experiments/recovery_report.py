"""Evidence audit, matched comparisons and a conservative research go/no-go gate."""

import argparse
import json
import math
from pathlib import Path
import random
from statistics import mean

from .recovery_benchmark import summarize


def bootstrap_difference(differences, seed=7, repetitions=5000):
    if not differences:
        return None
    generator = random.Random(seed)
    estimates = sorted(mean(generator.choices(differences, k=len(differences)))
                       for _ in range(repetitions))
    return {"pairs": len(differences), "mean_difference": mean(differences),
            "bootstrap_95": [estimates[int(0.025 * repetitions)], estimates[int(0.975 * repetitions)]]}


def paired_comparison(results, reference, proposed):
    by_method = {method: {(record["scenario"]["scenario_id"], record["seed"]): record
                         for record in results if record["method"] == method}
                 for method in (reference, proposed)}
    differences = []
    rejected = 0
    for key in by_method[reference].keys() & by_method[proposed].keys():
        first, second = by_method[reference][key], by_method[proposed][key]
        if (first["success"] is None or second["success"] is None
                or first.get("source_sha256") != second.get("source_sha256")
                or first["scenario"] != second["scenario"]):
            rejected += 1
            continue
        differences.append(int(second["success"]) - int(first["success"]))
    return {"reference": reference, "proposed": proposed,
            "success_difference": bootstrap_difference(differences), "rejected_pairs": rejected}


def probe_gate(results):
    by_scene = {}
    for record in results:
        if record["method"].startswith("probe_"):
            by_scene.setdefault(record["scenario"]["scenario_id"], []).append(record)
    comparable = []
    winners = set()
    for scene, values in by_scene.items():
        attempted = [record for record in values if record.get("recovery_decisions", 0)
                     and record["success"] is not None and record.get("first_failure_context")]
        if len(attempted) < 2:
            continue
        first = attempted[0]
        context = first["first_failure_context"]
        matched = all(record.get("source_sha256") == first.get("source_sha256")
                      and record["first_failure"]["reason"] == first["first_failure"]["reason"]
                      and math.dist(record["first_failure_context"]["base"], context["base"]) <= 0.03
                      and math.dist(record["first_failure_context"]["target"], context["target"]) <= 0.01
                      for record in attempted)
        if not matched:
            continue
        outcomes = {record["method"]: record.get("recovery_success", False) for record in attempted}
        comparable.append({"scenario_id": scene, "outcomes": outcomes})
        if len(set(outcomes.values())) > 1:
            winners.update(method for method, success in outcomes.items() if success)
    reasons = []
    if len(comparable) < 10:
        reasons.append("fewer than ten matched failure configurations with multiple actually executed actions")
    if len(winners) < 2:
        reasons.append("state-dependent advantages for at least two action types are not established")
    if not any(record.get("repeated_failure_calls", 0) for record in results):
        reasons.append("repeated-failure and memory benefit evidence is missing")
    return {"ready_for_expansion": not reasons, "matched_configurations": comparable,
            "distinct_advantaged_actions": sorted(winners), "reasons": reasons,
            "limitation": "state proximity is not an exact simulator/planner snapshot replay"}


def report(paths):
    results = [json.loads(Path(path).read_text()) for path in paths]
    return {"summary": summarize(results), "research_gate": probe_gate(results),
            "comparisons": [paired_comparison(results, reference, "learned_memory") for reference in (
                "original", "heuristic", "heuristic_memory", "learned")],
            "trial_paths": [str(path) for path in paths],
            "evidence_class": "mujoco_oracle_geometry_proxy",
            "claim": "descriptive simulator results only; no automatic claim of improvement or real-robot validity"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("inputs", nargs="+")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    result = report(args.inputs)
    Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(result["research_gate"], ensure_ascii=False))


if __name__ == "__main__":
    main()
