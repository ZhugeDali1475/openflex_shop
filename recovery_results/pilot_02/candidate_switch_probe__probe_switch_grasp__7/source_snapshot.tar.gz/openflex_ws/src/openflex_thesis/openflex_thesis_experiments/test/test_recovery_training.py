import pytest

from openflex_thesis_experiments.recovery_training import grouped_split, rows


def records():
    return [{"scenario_id": f"scene_{index}", "task_id": f"task_{index}", "label": outcome,
             "features": {"repeat_count": 3, "score": 0.8}, "action": "reobserve",
             "reason": "alignment", "stage": "align"}
            for index in range(10) for outcome in (0, 1)]


def test_grouped_split_never_leaks_tasks_or_scenarios():
    splits = grouped_split(records())
    groups = [set(record["scenario_id"] for record in values) for values in splits.values()]
    assert not groups[0] & groups[1]
    assert not groups[0] & groups[2]
    assert not groups[1] & groups[2]
    assert sum(len(values) for values in splits.values()) == 20


def test_small_dataset_is_rejected():
    with pytest.raises(ValueError):
        grouped_split(records()[:4])


def test_ablation_removes_memory_and_capability():
    row = rows(records()[:1], False, True)[0]
    assert row["repeat_count"] == 0
    assert row["score"] == 0
