from openflex_thesis_experiments.recovery_benchmark import classify_log, summarize


def test_terminal_success_wins_over_outer_timeout():
    assert classify_log("MUJOCO_MISSION_SUCCESS duration=12.3s", True)["success"] is True


def test_no_terminal_is_not_task_failure():
    assert classify_log("running", True) == {"status": "outer_timeout", "success": None}


def test_conflicting_terminals_are_invalid():
    text = 'RECOVERY_TASK_RESULT {"task_id":"a","success":true}\nRECOVERY_TASK_RESULT {"task_id":"a","success":false}'
    assert classify_log(text)["status"] == "invalid_terminal"


def test_infrastructure_is_reported_not_silently_discarded():
    report = summarize([{"method": "fixed", "success": True}, {"method": "fixed", "success": None}])
    assert report["fixed"]["valid_task_terminals"] == 1
    assert report["fixed"]["infrastructure_or_outer_timeout"] == 1
