"""Generate development probes and a separate frozen evaluation matrix."""

import argparse
import json
from pathlib import Path


def scenarios():
    values = []
    for index, noise in enumerate((0.005, 0.01, 0.02, 0.035, 0.05)):
        values.append({"scenario_id": f"observation_{index}", "family": "observation",
                       "observation_noise_m": noise})
    for index, lateral in enumerate((-0.2, -0.1, 0.1, 0.2, 0.3)):
        values.append({"scenario_id": f"base_{index}", "family": "base",
                       "pickup_pose": [0.0, lateral, 0.0]})
    for index, offsets in enumerate(([0.03, 0.08, 0.0], [0.0, 0.15, 0.0],
                                     [0.0, 0.25, 0.0], [0.1, 0.1, 0.1], [0.25, 0.25, 0.25])):
        values.append({"scenario_id": f"candidates_{index}", "family": "candidates",
                       "candidate_offsets_m": offsets})
    return [{"budget_sec": 420.0, "max_recovery_attempts": 1, "top_k": 3, **value} for value in values]


def matrix(phase, learned_model="", no_memory_model=""):
    methods = ("probe_reobserve", "probe_switch_grasp", "probe_reposition") if phase == "probe" else (
        ("random",) if phase == "collect" else ("original", "heuristic", "heuristic_memory", "learned", "learned_memory"))
    if phase == "evaluate" and not (learned_model and no_memory_model):
        raise ValueError("evaluation requires independently trained memory/no-memory models")
    return [{"scenario": scenario, "method": method, "seed": 1000 + index,
             "model_path": learned_model if method == "learned_memory" else no_memory_model if method == "learned" else ""}
            for index, scenario in enumerate(scenarios()) for method in methods]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("probe", "collect", "evaluate"))
    parser.add_argument("--output", required=True)
    parser.add_argument("--model", default="")
    parser.add_argument("--no-memory-model", default="")
    args = parser.parse_args()
    Path(args.output).write_text(json.dumps(matrix(args.phase, args.model, args.no_memory_model), indent=2) + "\n")


if __name__ == "__main__":
    main()
